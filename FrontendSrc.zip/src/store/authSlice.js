import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { authService } from '../services/authService';
import {
  readSavedUser,
  saveSessionSnapshot,
  setInMemoryAccessToken,
  clearSessionSnapshot,
} from '../services/backendApi';

const savedBootUser = readSavedUser();

const errText = (e) => e.response?.data?.message || e.message;
const thunk = (name, fn) =>
  createAsyncThunk(`auth/${name}`, (arg, { rejectWithValue }) =>
    fn(arg).catch((e) => rejectWithValue(errText(e))),
  );

export const login = thunk('login', authService.login);
export const signup = thunk('signup', authService.signup);
export const restoreSession = thunk('restoreSession', authService.restoreSession);
export const fetchMe = thunk('fetchMe', authService.me);
export const updateProfile = thunk('updateProfile', authService.updateProfile);
export const deleteMyAccount = thunk('deleteMyAccount', authService.deleteMyAccount);

const slice = createSlice({
  name: 'auth',
  initialState: {
    user: savedBootUser || null, // Hydrated immediately from localStorage ('user' / 'movieshub_user')
    access: null, // Strictly in React/Redux memory (never in localStorage)
    initializing: false,
    loading: false,
    error: null,
    logoutModalOpen: false,
  },
  reducers: {
    clearSession: (s, { payload } = {}) => {
      s.user = null;
      s.access = null;
      s.initializing = false;
      s.logoutModalOpen = false;
      clearSessionSnapshot({ broadcast: !payload?.fromBroadcast });
    },
    setAccess: (s, { payload }) => {
      s.access = payload || null;
      setInMemoryAccessToken(payload);
    },
    setSessionFromRefresh: (s, { payload }) => {
      // Never resurrect a session if localStorage user details were cleared/logged out
      if (!readSavedUser() && !payload?.fromBroadcast) {
        s.user = null;
        s.access = null;
        return;
      }
      s.access = payload?.access || s.access || null;
      if (payload?.user) {
        s.user = payload.user;
      }
      s.initializing = false;
      saveSessionSnapshot({
        user: s.user,
        access: s.access,
        fromBroadcast: Boolean(payload?.fromBroadcast),
      });
    },
    syncUserFromStorage: (s) => {
      const latestUser = readSavedUser();
      if (!latestUser) {
        s.user = null;
        s.access = null;
        s.initializing = false;
        s.logoutModalOpen = false;
        setInMemoryAccessToken(null);
      } else if (!s.user) {
        s.user = latestUser;
      }
    },
    clearError: (s) => {
      s.error = null;
    },
    openLogoutModal: (s) => {
      s.logoutModalOpen = true;
    },
    closeLogoutModal: (s) => {
      s.logoutModalOpen = false;
    },
  },
  extraReducers: (b) => {
    [login, signup].forEach((t) =>
      b
        .addCase(t.pending, (s) => {
          s.loading = true;
          s.error = null;
        })
        .addCase(t.fulfilled, (s, { payload }) => {
          s.loading = false;
          s.initializing = false;
          s.user = payload.user || null;
          s.access = payload.access || null;
          saveSessionSnapshot({
            user: payload.user,
            access: payload.access,
            isLoginOrSignup: true,
          });
        })
        .addCase(t.rejected, (s, a) => {
          s.loading = false;
          s.error = a.payload;
        }),
    );

    b.addCase(restoreSession.pending, (s) => {
      const localUser = readSavedUser();
      if (!localUser) {
        s.user = null;
        s.access = null;
      }
    });
    b.addCase(restoreSession.fulfilled, (s, { payload }) => {
      s.initializing = false;
      const localUser = readSavedUser();
      if (!payload?.user || !localUser) {
        // Rule 2: localStorage had no user details
        s.user = null;
        s.access = null;
      } else {
        s.user = payload.user;
        s.access = payload.access || s.access || null;
        saveSessionSnapshot({
          user: payload.user,
          access: s.access,
        });
      }
    });
    b.addCase(restoreSession.rejected, (s) => {
      // Rule 3: Refresh token expired or unauthorized (401/403)
      s.initializing = false;
      s.user = null;
      s.access = null;
      clearSessionSnapshot({ broadcast: true });
    });

    b.addCase(fetchMe.fulfilled, (s, { payload }) => {
      if (payload && readSavedUser()) {
        s.user = payload;
        saveSessionSnapshot({ user: payload });
      }
    });
    b.addCase(fetchMe.rejected, (s, a) => {
      if (String(a.payload || '').toLowerCase().includes('deactivated')) {
        s.user = null;
        s.access = null;
        s.error = a.payload;
        clearSessionSnapshot({ broadcast: true });
      }
    });

    b.addCase(updateProfile.fulfilled, (s, { payload }) => {
      if (payload && readSavedUser()) {
        s.user = payload;
        saveSessionSnapshot({ user: payload });
      }
    });

    b.addCase(deleteMyAccount.fulfilled, (s) => {
      s.user = null;
      s.access = null;
      s.logoutModalOpen = false;
      clearSessionSnapshot({ broadcast: true });
    });
  },
});

export const {
  clearSession,
  setAccess,
  setSessionFromRefresh,
  syncUserFromStorage,
  clearError,
  openLogoutModal,
  closeLogoutModal,
} = slice.actions;

export const logout = () => (dispatch) => {
  dispatch(clearSession({ fromBroadcast: false }));
  authService.logout().catch(() => {});
};

export default slice.reducer;
